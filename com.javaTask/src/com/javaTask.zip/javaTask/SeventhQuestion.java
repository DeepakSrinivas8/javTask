package com.javaTask;

public class SeventhQuestion {

	public static void main(String[] args) {
		for (int i=0;i<=100;i++) {
			if (i<10) {
				System.out.print(i+", ");
			}
			else if (i%11==0) {
				System.out.print(i+", ");
			}
				
		}

	}

}
