package com.javaTask;

import java.util.Scanner;

public class FourteenthQuestion {

	public static void main(String[] args) {
		Scanner s1=new Scanner(System.in);
		System.out.println("Enter the number");
		int n1=s1.nextInt();
		

	}

}
