package com.javaTask;

public class SixteenthQuestion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
